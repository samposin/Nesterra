export const CLEAR_ALL = 'CLEAR_ALL';
export const LOAD_LIST = 'LOAD_LIST';
export const SELECT_ALL = 'SELECT_ALL';
export const IS_SELECTED = 'IS_SELECTED';
export const SET_LAT_LNG = 'SET_LAT_LNG';

///COORDINATES
export const GET_COORDINATES = 'GET_COORDINATES';
///LOCATION DETAILS
export const LOCATION_DETAILS = 'LOCATION_DETAILS';

//Marker is seleted
export const MARKER_IS_SELECTED = 'MARKER_IS_SELECTED';
