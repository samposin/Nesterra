export const polyFirst = '60,20 71,20 71,50';
export const polySecond = '74.5,44 74.5,20 100,20';
export const polyThird = '100,70 120,70 130,75';
export const polyFour = '53,108 45,120 20,120';
export const polyFive = '48,43 40,34 30,34';
export const polySix = '36,90 30,95 15,95';
