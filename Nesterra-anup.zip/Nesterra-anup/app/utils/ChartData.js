//Invetory

export const indventory = [
  {x: 'one', y: 48.51},
  {x: 'two', y: 27.65},

  {x: 'Four', y: 22.34},
  {x: 'Five', y: 2.13},
  {x: 'Six', y: 0.2},
];
export const indventoryColor = [
  '#8ad4eb',
  '#4472c4',
  '#f2c80f',
  '#fd625e',
  '#01b8aa',
];
export const indventoryTotal = `2640`;
//Invetory
//annual
export const annualData = [
  {x: 'one', y: 48.51},
  {x: 'two', y: 27.65},

  {x: 'Four', y: 22.34},
  {x: 'Five', y: 2.13},
  {x: 'Six', y: 0.2},
];
export const annualTotal = `$47M`;
export const annualColor = [
  '#8ad4eb',
  '#4472c4',
  '#f2c80f',
  '#fd625e',
  '#01b8aa',
];
//annual

//circuit
export const circuitTotal = `19,596`;
export const circuitData = [
  {x: 'one', y: 61.2},
  {x: 'two', y: 18.96},
  {x: 'Five', y: 14.75},
  {x: 'Four', y: 4.58},
  {x: 'Six', y: 0.5052},
];
export const circuitColor = [
  '#4472c4',
  '#8ad4eb',
  '#f2c80f',
  '#fd625e',
  '#01b8aa',
]; // Colors
//circuit
