import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const Others = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  );
};

export default Others;

const styles = StyleSheet.create({});
