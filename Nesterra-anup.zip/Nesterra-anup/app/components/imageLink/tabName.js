export default {
    Explore:"Explore",
     ORDERS:"Orders",
    // PROFILE:"Profile",
    // SETTING:"Settings",
   
}