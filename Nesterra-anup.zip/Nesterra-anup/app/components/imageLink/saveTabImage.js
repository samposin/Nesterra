export default {
  imgAtm: require('../../images/atm-machine.png'),
  imgSite: require('../../images/location.png'),
  imgBranche: require('../../images/branch.png'),
  imgCircuits: require('../../images/iot.png'),
  imgDevices: require('../../images/ecg.png'),
  imgOrders: require('../../images/completed-task.png'),
  imgNotes: require('../../images/notes.png'),
};
