export default {
  imgExlore: require('../../images/thumbtack.png'),
  imgOrder: require('../../images/shopping-cart.png'),
  imgStats: require('../../images/signal-status.png'),
  imgAssets: require('../../images/star.png'),
  imgSearch: require('../../images/search.png'),
  bookmark: require('../../images/bookmark.png'),
  menu: require('../../images/menu.png'),
  report: require('../../images/clipboard.png'),
};
