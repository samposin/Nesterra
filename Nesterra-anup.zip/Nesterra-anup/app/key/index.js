export const LocationKey = 'AIzaSyAn9wVgUpu0h_LAHr0LPrzcKQjQ9uVczT8';
export const Base_url = 'https://citizenmobileapi.azurewebsites.net';
export const Base_url1 = 'https://citizenmobileapi-dev.azurewebsites.net/api/';

export const PhotoUrl =
  'https://maps.googleapis.com/maps/api/place/photo?maxwidth=1800&maxheight=1000&photoreference=';

// export const Base_url = 'http://192.168.56.1';
//const url = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&maxheight=500&photoreference=${item.photo_reference}&key=${LocationKey}`;
