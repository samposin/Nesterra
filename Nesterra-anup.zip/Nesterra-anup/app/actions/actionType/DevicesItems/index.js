export const DEVICES_ITEM = 'DEVICES_ITEM';
