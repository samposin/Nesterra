export const SITE_ITEM = 'SITE_ITEM';
export const SITE_ITEM_REMOVE = 'SITE_ITEM_REMOVE';
