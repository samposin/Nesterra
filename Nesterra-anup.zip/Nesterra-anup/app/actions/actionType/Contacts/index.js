export const ALL_CONTACT = 'ALL_CONTACT';
export const INDIVISUAL = 'INDIVISUAL';
export const VENDOR = 'VENDOR';
