export const ADD_NOTES = 'ADD_NOTES';
export const GET_NOTES = 'GET_NOTES';
