export const MAPTYPE = 'MAPTYPE';
