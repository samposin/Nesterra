export const DATA_CENTER = 'DATA_CENTER';

export const OFFICEE = 'OFFICEE';
export const BRANCH = 'BRANCH';
export const ATM = 'ATM';
export const THIRD_PARTY = 'THIRD_PARTY';
export const OTHER = 'OTHER';
export const SEARCH_CLEAR = 'SEARCH_CLEAR';
