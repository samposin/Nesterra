export const ALL_SITE_TYPE = 'ALL_SITE_TYPE';
export const IS_SELECTED = 'IS_SELECTED';
export const SEARCH_CLEARR = 'SEARCH_CLEARR';
