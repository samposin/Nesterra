export const getOrdersType = () => dispatch => {
  // if (data.length > 0) {
  //   // console.log(response.data);
  //   dispatch({
  //     type: ALL_ORDERS_TYPE,
  //     payload: {
  //       data: data,
  //     },
  //   });
  // }
  // console.log('first');
};
