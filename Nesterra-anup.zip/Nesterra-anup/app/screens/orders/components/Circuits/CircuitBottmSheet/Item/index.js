import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const Item = () => {
  return (
    <View>
      <Text>Item</Text>
    </View>
  );
};

export default Item;

const styles = StyleSheet.create({});
