import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const SiteCertiFication = () => {
  return (
    <View>
      <Text>SiteCertiFication</Text>
    </View>
  );
};

export default SiteCertiFication;

const styles = StyleSheet.create({});
