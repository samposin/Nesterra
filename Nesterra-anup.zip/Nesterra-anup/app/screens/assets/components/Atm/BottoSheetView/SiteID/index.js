import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const SiteID = () => {
  return (
    <View>
      <Text>SiteID</Text>
    </View>
  );
};

export default SiteID;

const styles = StyleSheet.create({});
