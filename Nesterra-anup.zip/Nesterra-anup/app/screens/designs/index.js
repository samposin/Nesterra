import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Design = () => {
  return (
    <View>
      <Text>Design</Text>
    </View>
  )
}

export default Design

const styles = StyleSheet.create({})