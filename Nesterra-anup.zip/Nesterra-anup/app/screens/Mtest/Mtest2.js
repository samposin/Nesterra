// import {StyleSheet, Text, SafeAreaView, StatusBar, View} from 'react-native';
// import React from 'react';
// import Device from './../../../appOld/screens/explore/components/RanderView/Components/Device/index';

// const Mtest2 = () => {
//   return (
//     <SafeAreaView
//       style={{
//         width: '100%',
//         marginTop: StatusBar.currentHeight,
//       }}>
//       <View
//         style={{
//           width: '100%',
//           height: 40,
//           backgroundColor: '#eee',
//           flexDirection: 'row',
//           justifyContent: 'space-evenly',
//         }}>
//         <View
//           style={{
//             width: '22%',
//             height: '100%',
//             backgroundColor: 'white',
//             borderRadius: 10,
//             borderWidth: 1,
//             borderColor: 'black',
//             alignItems: 'center',
//             justifyContent: 'center',
//           }}>
//           <Text style={{fontSize: 18, fontWeight: '700'}}>circutis</Text>
//         </View>
//         <View
//           style={{
//             width: '22%',
//             height: '100%',
//             backgroundColor: 'white',
//             borderRadius: 10,
//             borderWidth: 1,
//             borderColor: 'black',
//             alignItems: 'center',
//             justifyContent: 'center',
//           }}>
//           <Text style={{fontSize: 18, fontWeight: '700'}}>divice</Text>
//         </View>
//         <View
//           style={{
//             width: '22%',
//             height: '100%',
//             backgroundColor: 'white',
//             borderRadius: 10,
//             borderWidth: 1,
//             borderColor: 'black',
//             alignItems: 'center',
//             justifyContent: 'center',
//           }}>
//           <Text style={{fontSize: 18, fontWeight: '700'}}>ATMS</Text>
//         </View>
//         <View style={{width: '22%', height: '100%'}}></View>
//       </View>
//       <View style={{paddingVertical: '2%'}}>
//         <View
//           style={{
//             width: '100%',
//             height: 40,
//             backgroundColor: '#eee',
//             flexDirection: 'row',
//             justifyContent: 'space-evenly',
//           }}>
//           <View
//             style={{
//               width: '26%',
//               height: '100%',
//               backgroundColor: 'white',
//               borderRadius: 10,
//               borderWidth: 1,
//               borderColor: 'black',
//               // alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Text style={{fontSize: 15, fontWeight: '700', marginLeft: 5}}>
//               Name
//             </Text>
//           </View>
//           <View
//             style={{
//               width: '26%',
//               height: '100%',
//               backgroundColor: 'white',
//               borderRadius: 10,
//               borderWidth: 1,
//               borderColor: 'black',
//               alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Text style={{fontSize: 18, fontWeight: '700'}}>divice</Text>
//           </View>
//           <View
//             style={{
//               width: '26%',
//               height: '100%',
//               backgroundColor: 'white',
//               borderRadius: 10,
//               borderWidth: 1,
//               borderColor: 'black',
//               alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Text style={{fontSize: 18, fontWeight: '700'}}>ATMS</Text>
//           </View>
//           <View style={{width: '9%', height: '100%'}}></View>

//       </View>
//     </SafeAreaView>
//   );
// };

// export default Mtest2;

// const styles = StyleSheet.create({
//   itemBox: {
//     width: '30%',
//     height: '100%',
//     backgroundColor: '#007aff',
//     borderRadius: 5,
//     borderWidth: 3,
//     borderColor: 'black',
//   },
// });
import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const Mtest2 = () => {
  return (
    <View>
      <Text>Mtest2</Text>
    </View>
  );
};

export default Mtest2;

const styles = StyleSheet.create({});
