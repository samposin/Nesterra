import React from 'react';


// ItemID, SiteID, SmartSite#, Tangoe#, Carrier#
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
 export const data = {
     category:[
       {id:0,name: 'ItemID'},
       {id:1,name: 'SiteID'},
       {id:2,name: 'SmartSite'},
       {id:3,name: 'Tangoe'},
       {id:4,name: 'Carrier'},
    
    ]
  };