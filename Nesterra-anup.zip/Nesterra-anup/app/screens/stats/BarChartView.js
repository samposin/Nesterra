import {StyleSheet, Text, View, LogBox} from 'react-native';
import React from 'react';
LogBox.ignoreLogs([' node_modules/victory-vendor']);

const BarchartView = () => {
  return (
    <View>
      <Text>BarchartView</Text>
    </View>
  );
};

export default BarchartView;

const styles = StyleSheet.create({});
