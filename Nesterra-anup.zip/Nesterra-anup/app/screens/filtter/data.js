export const data1 = {
    category:[
      {id:0,name: 'Site Status'},
      {id:1,name: 'Country'},
      {id:2,name: 'Site Type'},
      {id:3,name: 'Site SubType'},
      {id:4,name: 'Vendor'},
   
   ]
 };